# AGENTS.md - Faceless Content Factory

This file guides agentic coding assistants working in this repo.
Read it before making changes.

## Project Summary

- Node.js + TypeScript (ESM) with CLI and background worker.
- Postgres via `pg`, SQL migrations in `src/db/migrations`.
- Runtime uses `ts-node/esm`; build uses `tsc` to `dist/`.

## Quick Start (Local)

1. `cp .env.example .env` and fill API keys.
2. `docker compose up -d`
3. `npm install`
4. `npm run migrate`
5. `npm run dev` (CLI help)

## Build / Lint / Test Commands

- Install deps: `npm install`
- Build (typecheck + emit): `npm run build`
- CLI help (ts-node): `npm run dev`
- CLI command: `npm run cli -- <command> [options]`
- Worker: `npm run worker`
- Migrations: `npm run migrate`
- QC server: `npm run qc` (script exists but `src/qc/server.ts` is missing)
- Docker Postgres: `docker compose up -d`

### Tests

- No test runner or test scripts are configured yet.
- Single test: not applicable until tests exist.
- If you add tests, prefer Node's built-in runner and document the command.
  Example: `node --test path/to/test-file.test.ts`

### Lint

- No lint script or config exists in this repo.
- Keep formatting consistent with existing files; do not introduce a new formatter.

## Code Style Guidelines

### Language and Module System

- TypeScript only; `tsconfig.json` is `strict`.
- ESM project (`"type": "module"`).
- Local imports include a `.js` suffix in TS source (ex: `./client.js`).
- Use `node:` prefix for core modules (ex: `node:fs`, `node:path`).
- Prefer `import type` for type-only imports.

### Formatting

- 2-space indentation.
- Single quotes for strings.
- Semicolons required.
- Keep functions small and linear; prefer early returns for invalid input.

### Naming

- `camelCase` for variables and functions.
- `PascalCase` for types and interfaces.
- `snake_case` for DB fields and payloads that map to DB columns.
- File names: `kebab-case` for multi-word files (see `src/worker/stages`).
- CLI registration functions are named `registerXCommand(s)`.

### Types

- Exported functions should have explicit return types when non-trivial.
- Use interfaces for data shapes, and union `type` aliases for enums.
- Avoid `any` except at DB boundaries or JSON blobs; prefer `unknown` + narrowing.
- Use `Partial<T>` for update payloads (see `updateJobStatus`).

### Imports

- Order is flexible, but keep groups readable.
- Avoid circular imports; data access is in `src/db/queries`.
- Do not import from `dist/` in source.

### Error Handling

- CLI commands validate inputs and exit with `process.exit(1)` on errors.
- Use `console.error` for failures, `console.log` for normal CLI output.
- Worker stages catch errors, update job status, and log failures.
- Required env vars should throw early (`mustGet` in `src/lib/config.ts`).

### Database and SQL

- Use `query<T>` from `src/db/client.ts` for all SQL.
- Always use parameterized queries (`$1`, `$2`, ...).
- For JSONB fields, pass `JSON.stringify(...)` and use `::jsonb` casts.
- Keep query functions in `src/db/queries/<entity>.ts`.

### Files and IO

- Use `fs.mkdirSync(..., { recursive: true })` before writing to new dirs.
- Temp output goes to `TEMP_DIR`; final output goes under `output/`.
- Do not commit generated artifacts in `output/` or `temp/`.

### CLI Commands

- Use `commander` and the `registerXCommand(s)` pattern.
- Validate required inputs at command boundaries.
- Prefer clear, single-line CLI output for automation.
- Keep help text consistent with `src/cli/commands/README.md`.

### Worker Pipeline

- Use `updateJobStatus` to transition states and capture stage metadata.
- Log stage progress with `createLog` (started/completed/failed).
- Keep stage names stable (`script`, `voice`, `footage`, `captions`, `assembly`).
- Write per-job artifacts under `TEMP_DIR/<job-id>/`.
- Bubble failures to job status with an `error_message`.

### API Clients

- OpenAI, ElevenLabs, and Pexels clients are configured in `src/lib/`.
- Warn when optional API keys are missing, but fail fast when required.
- Keep request timeouts explicit for external calls.

### Security and Secrets

- Never commit `.env` or API keys.
- Treat generated media outputs as build artifacts.
- Avoid logging secrets; redact if needed.

## Repository Structure

- `src/cli/` CLI entry and commands
- `src/db/` Postgres client, migrations, queries
- `src/lib/` API clients and shared utilities
- `src/types/` shared TypeScript types
- `src/worker/` polling loop and pipeline stages

## Environment

- `.env` is required for DB and API keys.
- Required envs are enforced in `src/lib/config.ts`.

## Cursor / Copilot Rules

- No `.cursor/rules/`, `.cursorrules`, or `.github/copilot-instructions.md` found.

## Notes

- `npm run qc` references `src/qc/server.ts` which is not present.
- Keep CLI output stable; scripts are used by automation.
