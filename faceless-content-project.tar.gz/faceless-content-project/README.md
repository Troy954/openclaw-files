# Faceless Content Factory

Internal engine to batch-generate faceless short-form videos.

## Quick start

1. Copy .env.example to .env and fill API keys (you can keep defaults for paths):

```
cp .env.example .env
```

2. Start Postgres via Docker Compose:

```
docker compose up -d
```

3. Install deps and run migrations:

```
npm install
npm run migrate
```

4. Check CLI skeleton:

```
npm run dev
```

Next phases add: channel management, job queue, and worker pipeline.
