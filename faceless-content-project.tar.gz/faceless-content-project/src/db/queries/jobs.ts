import { query } from '../../db/client.js';

export type JobStatus = 'queued' | 'processing' | 'completed' | 'failed';

export interface VideoJob {
  id: string;
  channel_id: string;
  topic: string;
  duration: number;
  status: JobStatus;
  current_stage?: string | null;
  script?: string | null;
  created_at?: string;
}

export async function createJob(channelId: string, topic: string, duration: number): Promise<VideoJob> {
  const { rows } = await query<VideoJob>(
    `INSERT INTO video_jobs (channel_id, topic, duration, status)
     VALUES ($1,$2,$3,'queued')
     RETURNING *`,
    [channelId, topic, duration]
  );
  return rows[0];
}

export async function createJobsBatch(jobs: { channelId: string; topic: string; duration: number }[]): Promise<number> {
  if (jobs.length === 0) return 0;
  const values: any[] = [];
  const placeholders = jobs.map((j, i) => {
    const base = i * 3;
    values.push(j.channelId, j.topic, j.duration);
    return `($${base + 1}, $${base + 2}, $${base + 3}, 'queued')`;
  });
  const sql = `INSERT INTO video_jobs (channel_id, topic, duration, status) VALUES ${placeholders.join(', ')}`;
  await query(sql, values);
  return jobs.length;
}

export async function getNextQueuedJob(): Promise<VideoJob | null> {
  const { rows } = await query<VideoJob>(
    `SELECT * FROM video_jobs WHERE status = 'queued' ORDER BY created_at ASC LIMIT 1`
  );
  return rows[0] || null;
}

export async function updateJobStatus(id: string, status: JobStatus, updates: Partial<VideoJob> = {}): Promise<VideoJob | null> {
  const fields: string[] = ['status = $1'];
  const values: any[] = [status];
  let idx = 2;
  for (const [k, v] of Object.entries(updates)) {
    if (v === undefined) continue;
    fields.push(`${k} = $${idx}`);
    values.push(v);
    idx++;
  }
  values.push(id);
  const { rows } = await query<VideoJob>(
    `UPDATE video_jobs SET ${fields.join(', ')} WHERE id = $${idx} RETURNING *`,
    values
  );
  return rows[0] || null;
}

export async function getJobsByStatus(status: JobStatus): Promise<VideoJob[]> {
  const { rows } = await query<VideoJob>(
    `SELECT * FROM video_jobs WHERE status = $1 ORDER BY created_at DESC`,
    [status]
  );
  return rows;
}

export async function getRecentJobs(limit = 10): Promise<VideoJob[]> {
  const { rows } = await query<VideoJob>(
    `SELECT * FROM video_jobs ORDER BY created_at DESC LIMIT $1`,
    [limit]
  );
  return rows;
}

export async function getQueueSummary(): Promise<{ status: JobStatus; count: number }[]> {
  const { rows } = await query<{ status: JobStatus; count: number }>(
    `SELECT status, COUNT(*)::int as count FROM video_jobs GROUP BY status ORDER BY status`
  );
  return rows;
}
