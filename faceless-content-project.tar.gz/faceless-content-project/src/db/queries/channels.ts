import { query } from '../../db/client.js';
import type { Channel } from '../../types/index.js';

export async function listChannels(): Promise<Channel[]> {
  const { rows } = await query<Channel>('SELECT * FROM channels ORDER BY created_at DESC');
  return rows;
}

export async function getChannel(id: string): Promise<Channel | null> {
  const { rows } = await query<Channel>('SELECT * FROM channels WHERE id = $1', [id]);
  return rows[0] || null;
}

interface CreateChannelInput {
  id: string;
  name: string;
  niche?: string;
  voice_id?: string;
  voice_settings?: object;
  caption_style?: object;
  content_guidelines?: string;
  output_directory: string;
  is_active?: boolean;
}

export async function createChannel(input: CreateChannelInput): Promise<Channel> {
  const {
    id,
    name,
    niche = null,
    voice_id = null,
    voice_settings = {},
    caption_style = {},
    content_guidelines = null,
    output_directory,
    is_active = true,
  } = input;
  const { rows } = await query<Channel>(
    `INSERT INTO channels (id, name, niche, voice_id, voice_settings, caption_style, content_guidelines, output_directory, is_active)
     VALUES ($1,$2,$3,$4,$5::jsonb,$6::jsonb,$7,$8,$9)
     RETURNING *`,
    [id, name, niche, voice_id, JSON.stringify(voice_settings), JSON.stringify(caption_style), content_guidelines, output_directory, is_active]
  );
  return rows[0];
}

interface UpdateChannelInput {
  name?: string;
  niche?: string | null;
  voice_id?: string | null;
  voice_settings?: object;
  caption_style?: object;
  content_guidelines?: string | null;
  output_directory?: string;
  is_active?: boolean;
}

export async function updateChannel(id: string, updates: UpdateChannelInput): Promise<Channel | null> {
  const fields: string[] = [];
  const values: any[] = [];
  let idx = 1;
  for (const [k, v] of Object.entries(updates)) {
    if (v === undefined) continue;
    if (k === 'voice_settings' || k === 'caption_style') {
      fields.push(`${k} = $${idx}::jsonb`);
      values.push(JSON.stringify(v));
    } else {
      fields.push(`${k} = $${idx}`);
      values.push(v);
    }
    idx++;
  }
  if (fields.length === 0) return getChannel(id);
  values.push(id);
  const { rows } = await query<Channel>(
    `UPDATE channels SET ${fields.join(', ')}, updated_at = now() WHERE id = $${idx} RETURNING *`,
    values
  );
  return rows[0] || null;
}

export async function deleteChannel(id: string): Promise<{ id: string } | null> {
  const existing = await getChannel(id);
  if (!existing) return null;
  await query('DELETE FROM channels WHERE id = $1', [id]);
  return { id };
}
