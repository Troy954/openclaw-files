import { query } from '../../db/client.js';

export interface GenerationLog {
  id?: string;
  job_id: string;
  stage: string;
  status: 'started' | 'completed' | 'failed';
  duration_ms?: number;
  cost_cents?: number;
  details?: object;
  error?: string;
}

export async function createLog(input: GenerationLog): Promise<void> {
  const {
    job_id,
    stage,
    status,
    duration_ms = null,
    cost_cents = 0,
    details = null,
    error = null,
  } = input;

  await query(
    `INSERT INTO generation_logs (job_id, stage, status, duration_ms, cost_cents, details, error)
     VALUES ($1,$2,$3,$4,$5,$6::jsonb,$7)`,
    [job_id, stage, status, duration_ms, cost_cents, details ? JSON.stringify(details) : null, error]
  );
}
