import fs from 'node:fs';
import path from 'node:path';
import { query } from './client.js';

async function run() {
  const migrationsDir = path.resolve('src/db/migrations');
  const files = fs.readdirSync(migrationsDir).filter(f => f.endsWith('.sql')).sort();
  for (const file of files) {
    const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf8');
    console.log(`Applying migration: ${file}`);
    await query(sql);
  }
  console.log('Migrations applied');
  process.exit(0);
}

run().catch(err => {
  console.error(err);
  process.exit(1);
});
