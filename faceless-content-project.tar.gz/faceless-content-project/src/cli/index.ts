#!/usr/bin/env node
import 'dotenv/config';
import { Command } from 'commander';
import { registerChannelsCommands } from './commands/channels.js';
import { registerGenerateCommand } from './commands/generate.js';
import { registerImportCommand } from './commands/import.js';
import { registerStatusCommand } from './commands/status.js';

const program = new Command();
program
  .name('fcf')
  .description('Faceless Content Factory CLI')
  .version('0.1.0');

// Phase 2: channels CRUD
registerChannelsCommands(program);

// Phase 3: jobs
registerGenerateCommand(program);
registerImportCommand(program);
registerStatusCommand(program);

program.parseAsync(process.argv);
