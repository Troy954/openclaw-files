import { Command } from 'commander';
import { createChannel, deleteChannel, getChannel, listChannels, updateChannel } from '../../db/queries/channels.js';
import crypto from 'node:crypto';

export function registerChannelsCommands(program: Command) {
  const cmd = program.command('channels').description('Manage channel configurations');

  cmd
    .command('list')
    .description('List channels')
    .action(async () => {
      const rows = await listChannels();
      if (rows.length === 0) {
        console.log('No channels found');
        return;
      }
      for (const c of rows) {
        console.log(`${c.id}\t${c.name}\tactive=${c.is_active}\toutput=${c.output_directory}`);
      }
    });

  cmd
    .command('add')
    .description('Add a new channel')
    .requiredOption('--name <name>', 'Channel name')
    .requiredOption('--output <dir>', 'Output directory')
    .option('--id <id>', 'Channel id (default: slug of name)')
    .option('--niche <niche>', 'Niche/vertical')
    .option('--voice-id <voiceId>', 'Voice ID')
    .option('--active', 'Set channel active')
    .option('--inactive', 'Set channel inactive')
    .action(async (opts) => {
      const id = opts.id ?? slugify(opts.name);
      const isActive = opts.inactive ? false : true;
      const created = await createChannel({
        id,
        name: opts.name,
        niche: opts.niche,
        voice_id: opts.voiceId,
        voice_settings: {},
        caption_style: {},
        content_guidelines: null,
        output_directory: opts.output,
        is_active: isActive,
      });
      console.log('Created channel:', created.id, created.name);
    });

  cmd
    .command('update')
    .description('Update a channel')
    .requiredOption('--id <id>', 'Channel id')
    .option('--name <name>')
    .option('--niche <niche>')
    .option('--voice-id <voiceId>')
    .option('--output <dir>')
    .option('--active', 'Set active')
    .option('--inactive', 'Set inactive')
    .action(async (opts) => {
      const updates: any = {};
      if (opts.name) updates.name = opts.name;
      if (opts.niche) updates.niche = opts.niche;
      if (opts.voiceId) updates.voice_id = opts.voiceId;
      if (opts.output) updates.output_directory = opts.output;
      if (opts.active) updates.is_active = true;
      if (opts.inactive) updates.is_active = false;
      const updated = await updateChannel(opts.id, updates);
      if (!updated) {
        console.error('Channel not found');
        process.exit(1);
      }
      console.log('Updated channel:', updated.id, updated.name);
    });

  cmd
    .command('delete')
    .description('Delete a channel')
    .requiredOption('--id <id>', 'Channel id')
    .action(async (opts) => {
      const deleted = await deleteChannel(opts.id);
      if (!deleted) {
        console.error('Channel not found');
        process.exit(1);
      }
      console.log('Deleted channel:', deleted.id);
    });

  cmd
    .command('enable')
    .description('Enable a channel')
    .requiredOption('--id <id>', 'Channel id')
    .action(async (opts) => {
      const updated = await updateChannel(opts.id, { is_active: true });
      if (!updated) {
        console.error('Channel not found');
        process.exit(1);
      }
      console.log('Enabled channel:', updated.id);
    });

  cmd
    .command('disable')
    .description('Disable a channel')
    .requiredOption('--id <id>', 'Channel id')
    .action(async (opts) => {
      const updated = await updateChannel(opts.id, { is_active: false });
      if (!updated) {
        console.error('Channel not found');
        process.exit(1);
      }
      console.log('Disabled channel:', updated.id);
    });
}

function slugify(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '')
    || crypto.randomUUID();
}
