import { Command } from 'commander';
import { getJobsByStatus, getQueueSummary, getRecentJobs } from '../../db/queries/jobs.js';

export function registerStatusCommand(program: Command) {
  program
    .command('status')
    .description('Show queue status')
    .option('--queued', 'List queued jobs')
    .option('--processing', 'List processing jobs')
    .option('--completed', 'List completed jobs')
    .option('--failed', 'List failed jobs')
    .option('--limit <n>', 'Limit results (default 10)', '10')
    .action(async (opts) => {
      const limit = Number(opts.limit || 10);
      if (opts.queued) return printList(await getJobsByStatus('queued'), limit);
      if (opts.processing) return printList(await getJobsByStatus('processing'), limit);
      if (opts.completed) return printList(await getJobsByStatus('completed'), limit);
      if (opts.failed) return printList(await getJobsByStatus('failed'), limit);

      const summary = await getQueueSummary();
      if (summary.length === 0) {
        console.log('Status: queued=0 processing=0 completed=0 failed=0');
        return;
      }
      const counts: Record<string, number> = { queued: 0, processing: 0, completed: 0, failed: 0 };
      for (const row of summary) counts[row.status] = row.count;
      console.log(`Status: queued=${counts.queued} processing=${counts.processing} completed=${counts.completed} failed=${counts.failed}`);
    });
}

function printList(rows: any[], limit: number) {
  const slice = rows.slice(0, limit);
  if (slice.length === 0) {
    console.log('No jobs found');
    return;
  }
  for (const r of slice) {
    console.log(`${r.id}\t${r.status}\t${r.channel_id}\t${r.topic}\t${r.duration}`);
  }
}
