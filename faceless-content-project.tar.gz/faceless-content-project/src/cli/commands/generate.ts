import { Command } from 'commander';
import fs from 'node:fs';
import path from 'node:path';
import { createJob, createJobsBatch } from '../../db/queries/jobs.js';

export function registerGenerateCommand(program: Command) {
  program
    .command('generate')
    .description('Queue video jobs')
    .requiredOption('--channel <id>', 'Channel id')
    .option('--topic <topic>', 'Single topic to queue')
    .option('--duration <seconds>', 'Duration (30|60|90)', '60')
    .option('--topics-file <path>', 'File with one topic per line')
    .action(async (opts) => {
      const duration = Number(opts.duration);
      if (![30, 60, 90].includes(duration)) {
        console.error('Duration must be 30, 60, or 90');
        process.exit(1);
      }

      if (opts.topic) {
        const job = await createJob(opts.channel, opts.topic, duration);
        console.log('Queued job:', job.id, job.topic, `duration=${job.duration}`);
        return;
      }

      if (opts.topicsFile) {
        const filePath = path.resolve(opts.topicsFile);
        const content = fs.readFileSync(filePath, 'utf8');
        const topics = content
          .split(/\r?\n/)
          .map(t => t.trim())
          .filter(Boolean);
        const batch = topics.map(topic => ({ channelId: opts.channel, topic, duration }));
        const count = await createJobsBatch(batch);
        console.log(`Queued ${count} jobs from ${filePath}`);
        return;
      }

      console.error('Provide --topic or --topics-file');
      process.exit(1);
    });
}
