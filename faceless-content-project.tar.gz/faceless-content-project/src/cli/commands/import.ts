import { Command } from 'commander';
import fs from 'node:fs';
import path from 'node:path';
import { createJobsBatch } from '../../db/queries/jobs.js';

// CSV format: channel_id,topic,duration
export function registerImportCommand(program: Command) {
  program
    .command('import')
    .description('Import jobs from CSV')
    .argument('<file>', 'CSV file with jobs')
    .action(async (file) => {
      const filePath = path.resolve(file);
      const content = fs.readFileSync(filePath, 'utf8');
      const lines = content.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
      const jobs = [] as { channelId: string; topic: string; duration: number }[];

      let header: string[] | null = null;
      if (lines[0] && /topic/i.test(lines[0]) && /channel/i.test(lines[0])) {
        header = lines.shift()!.split(',').map(s => s.trim().toLowerCase());
      }

      for (const line of lines) {
        if (line.startsWith('#')) continue;
        const cols = line.split(',').map(s => s.trim());
        let channelId = '';
        let topic = '';
        let durationStr = '';

        if (header) {
          const idxTopic = header.indexOf('topic');
          const idxChannel = header.indexOf('channel') >= 0 ? header.indexOf('channel') : header.indexOf('channel_id');
          const idxDuration = header.indexOf('duration');
          topic = cols[idxTopic] || '';
          channelId = cols[idxChannel] || '';
          durationStr = cols[idxDuration] || '';
        } else if (cols.length >= 4) {
          // PRD format: topic, channel, duration, voice_profile (ignored)
          [topic, channelId, durationStr] = cols;
        } else {
          // Legacy format: channel_id, topic, duration
          [channelId, topic, durationStr] = cols;
        }

        const duration = Number(durationStr || '60');
        if (!channelId || !topic || ![30, 60, 90].includes(duration)) {
          console.error('Invalid row:', line);
          continue;
        }
        jobs.push({ channelId, topic, duration });
      }
      const count = await createJobsBatch(jobs);
      console.log(`Imported ${count} jobs from ${filePath}`);
    });
}
