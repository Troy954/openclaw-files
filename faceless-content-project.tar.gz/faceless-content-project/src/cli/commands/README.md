# CLI Commands

This folder contains the CLI subcommands used to operate the Faceless Content Factory from the terminal. It’s the primary interface for queueing jobs, managing channels, and checking queue status.

Run commands via:

```bash
npm run cli -- <command> [options]
```

Quick help:

```bash
npm run cli -- --help
```

---

## Environment & Setup

These commands read from `.env` at project root. Minimum required for most commands:

- `DATABASE_URL=postgresql://fcf:fcf@localhost:5432/fcf`

If DB isn’t running, you’ll see connection errors. Start it with:

```bash
docker compose up -d
```

---

## Channels

Manage channel configurations (voice, style, output paths). Channels define how jobs should be generated.

### Commands

**List channels**
```bash
npm run cli -- channels list
```

**Add a channel**
```bash
npm run cli -- channels add \
  --id finance-shorts \
  --name "Finance Shorts" \
  --niche finance \
  --voice-id v123 \
  --output ./output/finance
```

**Update a channel**
```bash
npm run cli -- channels update \
  --id finance-shorts \
  --voice-id v456 \
  --output ./output/finance
```

**Enable / Disable**
```bash
npm run cli -- channels disable --id finance-shorts
npm run cli -- channels enable --id finance-shorts
```

**Delete**
```bash
npm run cli -- channels delete --id finance-shorts
```

### Options (channels add)
- `--id <id>`: channel id (optional; defaults to slug of name)
- `--name <name>`: display name (**required**)
- `--niche <niche>`: channel niche/vertical (optional)
- `--voice-id <voiceId>`: ElevenLabs voice ID (optional)
- `--output <dir>`: output directory (**required**)
- `--active`: set channel active
- `--inactive`: set channel inactive

### Options (channels update)
- `--id <id>`: channel id (**required**)
- `--name <name>`
- `--niche <niche>`
- `--voice-id <voiceId>`
- `--output <dir>`
- `--active` / `--inactive`

### Example Output
```
finance-shorts  Finance Shorts  active=true  output=./output/finance
```

Common errors:
- **“Channel not found”** → check the id; run `channels list`.
- **Duplicate key** → a channel with the same id already exists.

---

## Generate (Queue Jobs)

Queue video jobs for processing.

### Commands

**Queue a single job**
```bash
npm run cli -- generate \
  --channel finance-shorts \
  --duration 60 \
  --topic "How compound interest works"
```

**Queue jobs from a topics file** (one topic per line)
```bash
npm run cli -- generate \
  --channel finance-shorts \
  --duration 60 \
  --topics-file topics.txt
```

### Options
- `--channel <id>`: channel id (**required**)
- `--topic <text>`: single topic
- `--topics-file <path>`: file with one topic per line
- `--duration <seconds>`: 30, 60, or 90 (default: 60)

### Example Output
```
Queued job: 1c7141d0-fe15-4768-ae4c-26abf2daa891 How to stay focused duration=60
```

Common errors:
- **“Duration must be 30, 60, or 90”** → use only those values.
- **“Provide --topic or --topics-file”** → one is required.

---

## Import (CSV)

Queue jobs from a CSV file. Supported formats:

1) **PRD format**: `topic,channel,duration,voice_profile`
2) **Header-based CSV**: `topic, channel, duration` (or `channel_id`)
3) **Legacy format**: `channel_id,topic,duration`

### Commands
```bash
npm run cli -- import jobs.csv
```

### CSV Examples

**PRD format**
```
How compound interest works,finance-shorts,60,voiceA
5 saving hacks,finance-shorts,60,voiceA
```

**Header-based**
```
topic,channel,duration
How compound interest works,finance-shorts,60
5 saving hacks,finance-shorts,60
```

**Legacy**
```
finance-shorts,How compound interest works,60
finance-shorts,5 saving hacks,60
```

### Example Output
```
Imported 12 jobs from /path/to/jobs.csv
```

Common errors:
- **“Invalid row”** → malformed CSV row or invalid duration.

---

## Status

Check queue status or list jobs by status.

### Commands

**Summary counts**
```bash
npm run cli -- status
```

**List queued jobs**
```bash
npm run cli -- status --queued --limit 20
```

**List completed jobs**
```bash
npm run cli -- status --completed --limit 20
```

### Options
- `--queued | --processing | --completed | --failed`
- `--limit <n>`: default 10

### Example Output
```
Status: queued=3 processing=0 completed=0 failed=0
```

---

## Troubleshooting

- **DB connection errors** → confirm docker compose is up and `DATABASE_URL` is correct.
- **CLI not running** → ensure `npm install` has been run and `npm run cli -- --help` works.
- **No jobs showing** → check if jobs were queued under the expected channel.

---

## Notes

- Commands are intentionally minimal; no interactive prompts yet.
- See `src/cli/index.ts` for how commands are registered.
