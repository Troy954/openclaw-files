import OpenAI from 'openai';
import { config } from './config.js';

if (!config.openaiApiKey) {
  // Allow worker to start even if OpenAI key isn't set (will fail when used)
  console.warn('OPENAI_API_KEY not set');
}

export const openai = new OpenAI({ apiKey: config.openaiApiKey });
