import axios from 'axios';
import { config } from './config.js';
import type { VoiceSettings } from '../types/index.js';

const BASE_URL = 'https://api.elevenlabs.io/v1';

if (!config.elevenlabsApiKey) {
  console.warn('ELEVENLABS_API_KEY not set');
}

export async function synthesizeSpeech(text: string, voiceId: string, settings: VoiceSettings = {}): Promise<Buffer> {
  if (!voiceId) throw new Error('Voice ID is required for ElevenLabs');
  if (!config.elevenlabsApiKey) throw new Error('ELEVENLABS_API_KEY is not set');

  const url = `${BASE_URL}/text-to-speech/${voiceId}`;
  const payload = {
    text,
    model_id: 'eleven_monolingual_v1',
    voice_settings: {
      stability: settings.stability ?? 0.5,
      similarity_boost: settings.similarity_boost ?? 0.7,
      style: settings.style ?? 0,
      use_speaker_boost: settings.use_speaker_boost ?? true,
    },
  };

  const res = await axios.post(url, payload, {
    responseType: 'arraybuffer',
    headers: {
      'xi-api-key': config.elevenlabsApiKey,
      'Content-Type': 'application/json',
      'Accept': 'audio/mpeg',
    },
    timeout: 60_000,
  });

  return Buffer.from(res.data);
}
