import 'dotenv/config';

export const config = {
  databaseUrl: mustGet('DATABASE_URL'),
  openaiApiKey: process.env.OPENAI_API_KEY || '',
  openaiModel: process.env.OPENAI_MODEL || 'gpt-4',
  openaiAudioModel: process.env.OPENAI_AUDIO_MODEL || 'whisper-1',
  elevenlabsApiKey: process.env.ELEVENLABS_API_KEY || '',
  pexelsApiKey: process.env.PEXELS_API_KEY || '',
  tempDir: mustGet('TEMP_DIR'),
  workerPollIntervalMs: Number(process.env.WORKER_POLL_INTERVAL_MS || '5000'),
};

function mustGet(key: string): string {
  const val = process.env[key];
  if (!val) throw new Error(`${key} is not set`);
  return val;
}
