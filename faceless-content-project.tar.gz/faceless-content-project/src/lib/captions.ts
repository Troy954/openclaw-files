import type { CaptionStyle } from '../types/index.js';

interface Segment {
  start: number;
  end: number;
  text: string;
}

export function generateASSFromSegments(segments: Segment[], style: CaptionStyle = {}): string {
  const font = style.font || 'Arial';
  const fontSize = style.fontSize || 60;
  const primary = assColor(style.primaryColor || '#FFFFFF');
  const outline = assColor(style.outlineColor || '#000000');
  const shadow = assColor(style.shadowColor || '#000000');
  const alignment = positionToAlignment(style.position || 'bottom');

  const header = `[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,${font},${fontSize},${primary},${primary},${outline},${shadow},0,0,0,0,100,100,0,0,1,3,0,${alignment},60,60,120,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
`;

  const events = segments.map(seg => {
    const start = toASSTime(seg.start);
    const end = toASSTime(seg.end);
    const text = seg.text.replace(/\r?\n/g, ' ').trim();
    return `Dialogue: 0,${start},${end},Default,,0,0,0,,${text}`;
  });

  return header + events.join('\n') + '\n';
}

function toASSTime(seconds: number): string {
  const cs = Math.max(0, Math.round(seconds * 100));
  const h = Math.floor(cs / 360000);
  const m = Math.floor((cs % 360000) / 6000);
  const s = Math.floor((cs % 6000) / 100);
  const c = cs % 100;
  return `${h}:${pad(m)}:${pad(s)}.${pad(c)}`;
}

function pad(n: number): string {
  return n.toString().padStart(2, '0');
}

// Convert #RRGGBB to ASS &HBBGGRR
function assColor(hex: string): string {
  const h = hex.replace('#', '').trim();
  if (h.length !== 6) return '&H00FFFFFF';
  const r = h.slice(0, 2);
  const g = h.slice(2, 4);
  const b = h.slice(4, 6);
  return `&H00${b}${g}${r}`.toUpperCase();
}

function positionToAlignment(pos: 'bottom' | 'middle' | 'top'): number {
  switch (pos) {
    case 'top':
      return 8;
    case 'middle':
      return 5;
    case 'bottom':
    default:
      return 2;
  }
}
