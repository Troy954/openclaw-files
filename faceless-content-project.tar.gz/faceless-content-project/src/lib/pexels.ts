import axios from 'axios';
import fs from 'node:fs';
import path from 'node:path';
import { config } from './config.js';

const BASE_URL = 'https://api.pexels.com/videos';

if (!config.pexelsApiKey) {
  console.warn('PEXELS_API_KEY not set');
}

export interface PexelsVideoFile {
  id: number;
  quality: string;
  file_type: string;
  width: number;
  height: number;
  link: string;
}

export interface PexelsVideo {
  id: number;
  url: string;
  duration: number;
  video_files: PexelsVideoFile[];
}

export async function searchVideos(query: string, perPage = 5): Promise<PexelsVideo[]> {
  if (!config.pexelsApiKey) throw new Error('PEXELS_API_KEY is not set');
  const url = `${BASE_URL}/search`;
  const res = await axios.get(url, {
    headers: { Authorization: config.pexelsApiKey },
    params: { query, per_page: perPage },
    timeout: 30_000,
  });
  return res.data?.videos || [];
}

export async function downloadVideo(url: string, outputPath: string): Promise<void> {
  const dir = path.dirname(outputPath);
  fs.mkdirSync(dir, { recursive: true });
  const res = await axios.get(url, { responseType: 'stream', timeout: 60_000 });
  await new Promise<void>((resolve, reject) => {
    const stream = fs.createWriteStream(outputPath);
    res.data.pipe(stream);
    stream.on('finish', () => resolve());
    stream.on('error', reject);
  });
}

export function pickBestFile(video: PexelsVideo): PexelsVideoFile | null {
  if (!video.video_files?.length) return null;
  const sorted = [...video.video_files].sort((a, b) => {
    // Prefer higher resolution, then lower size (approx via width*height)
    const aSize = (a.width || 0) * (a.height || 0);
    const bSize = (b.width || 0) * (b.height || 0);
    return bSize - aSize;
  });
  return sorted[0] || null;
}
