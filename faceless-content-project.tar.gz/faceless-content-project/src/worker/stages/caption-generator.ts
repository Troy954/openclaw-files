import fs from 'node:fs';
import path from 'node:path';
import type { Channel } from '../../types/index.js';
import { openai } from '../../lib/openai.js';
import { config } from '../../lib/config.js';
import { generateASSFromSegments } from '../../lib/captions.js';

interface WhisperSegment {
  start: number;
  end: number;
  text: string;
}

export async function generateCaptions(audioPath: string, channel: Channel, jobId: string): Promise<string> {
  const file = fs.createReadStream(audioPath);

  const response: any = await openai.audio.transcriptions.create({
    file,
    model: config.openaiAudioModel || 'whisper-1',
    response_format: 'verbose_json',
    timestamp_granularities: ['segment'],
  });

  const segments: WhisperSegment[] = response?.segments || [];
  if (!segments.length) throw new Error('Whisper returned no segments');

  const ass = generateASSFromSegments(segments, channel.caption_style || {});

  const jobDir = path.join(config.tempDir, jobId);
  fs.mkdirSync(jobDir, { recursive: true });
  const captionsPath = path.join(jobDir, 'captions.ass');
  fs.writeFileSync(captionsPath, ass, 'utf8');

  return captionsPath;
}
