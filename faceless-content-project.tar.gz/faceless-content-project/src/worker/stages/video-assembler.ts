import fs from 'node:fs';
import path from 'node:path';
import ffmpeg from 'fluent-ffmpeg';
import { config } from '../../lib/config.js';

interface AssembleInput {
  clipPaths: string[];
  voiceoverPath: string;
  captionsPath: string;
  jobId: string;
}

export interface AssembleResult {
  videoPath: string;
  thumbnailPath: string;
}

export async function assembleVideo(input: AssembleInput): Promise<AssembleResult> {
  const { clipPaths, voiceoverPath, captionsPath, jobId } = input;
  if (!clipPaths.length) throw new Error('No clips to assemble');

  const jobDir = path.join(config.tempDir, jobId);
  fs.mkdirSync(jobDir, { recursive: true });

  const concatList = path.join(jobDir, 'concat.txt');
  fs.writeFileSync(concatList, clipPaths.map(p => `file '${p.replace(/'/g, "'\\''")}'`).join('\n'));

  const videoPath = path.join(jobDir, 'video.mp4');

  await new Promise<void>((resolve, reject) => {
    ffmpeg()
      .input(concatList)
      .inputOptions(['-f concat', '-safe 0'])
      .input(voiceoverPath)
      .outputOptions([
        '-shortest',
        '-movflags +faststart',
        '-r 30',
        '-c:v libx264',
        '-c:a aac',
      ])
      .videoFilters([
        "scale=1080:1920:force_original_aspect_ratio=increase",
        "crop=1080:1920",
        `subtitles='${captionsPath.replace(/'/g, "'\\''")}'`,
      ])
      .save(videoPath)
      .on('end', () => resolve())
      .on('error', reject);
  });

  const thumbnailPath = path.join(jobDir, 'thumbnail.jpg');
  await new Promise<void>((resolve, reject) => {
    ffmpeg(videoPath)
      .screenshots({ count: 1, timemarks: ['3'], filename: path.basename(thumbnailPath), folder: jobDir })
      .on('end', () => resolve())
      .on('error', reject);
  });

  return { videoPath, thumbnailPath };
}
