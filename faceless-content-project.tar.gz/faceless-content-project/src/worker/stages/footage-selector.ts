import path from 'node:path';
import fs from 'node:fs';
import { config } from '../../lib/config.js';
import { searchVideos, downloadVideo, pickBestFile } from '../../lib/pexels.js';
import { trimVideo } from '../utils/ffmpeg.js';

export interface FootageResult {
  clipPaths: string[];
  footageUrls: string[];
}

interface ScriptSegment {
  startSec: number | null;
  endSec: number | null;
  visual: string | null;
}

export async function selectFootage(script: string, jobId: string, totalDurationSeconds?: number): Promise<FootageResult> {
  const segments = parseScriptSegments(script);
  const visuals = segments.filter(s => s.visual && s.visual.trim().length > 0);

  if (visuals.length === 0) {
    throw new Error('No VISUAL markers found in script');
  }

  const jobDir = path.join(config.tempDir, jobId, 'footage');
  fs.mkdirSync(jobDir, { recursive: true });

  // Compute durations for each segment
  const durations = computeDurations(visuals, totalDurationSeconds);

  const clipPaths: string[] = [];
  const footageUrls: string[] = [];

  for (let i = 0; i < visuals.length; i++) {
    const visual = visuals[i].visual!.trim();
    const query = extractKeyword(visual);
    const duration = durations[i];

    const videos = await searchVideos(query, 5);
    if (videos.length === 0) {
      throw new Error(`No Pexels results for visual: ${visual}`);
    }

    const best = pickBestFile(videos[0]);
    if (!best) {
      throw new Error(`No downloadable file found for visual: ${visual}`);
    }

    const rawPath = path.join(jobDir, `clip_${i + 1}_raw.mp4`);
    await downloadVideo(best.link, rawPath);

    const trimmedPath = path.join(jobDir, `clip_${i + 1}.mp4`);
    const start = 0;
    const safeDuration = Math.max(1, Math.floor(duration));
    await trimVideo(rawPath, trimmedPath, start, safeDuration);

    clipPaths.push(trimmedPath);
    footageUrls.push(videos[0].url || best.link);
  }

  return { clipPaths, footageUrls };
}

function extractKeyword(visual: string): string {
  const normalized = visual
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  const stopwords = new Set([
    'a', 'an', 'the', 'of', 'to', 'in', 'on', 'with', 'for', 'from', 'by', 'and',
    'close', 'up', 'close-up', 'person', 'people', 'man', 'woman', 'someone',
    'hands', 'hand', 'screen', 'text', 'animation', 'shot', 'view', 'scene',
  ]);

  const tokens = normalized.split(' ').filter(Boolean);
  const filtered = tokens.filter(token => !stopwords.has(token));

  const candidate = filtered[0] || tokens[0] || visual.trim();
  if (candidate.includes('$') || candidate.includes('dollar') || candidate.includes('money') || candidate.includes('cash') || candidate.includes('bill')) {
    return 'money';
  }

  if (/^\d+$/.test(candidate)) {
    return 'money';
  }

  return candidate;
}

function parseScriptSegments(script: string): ScriptSegment[] {
  const lines = script.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
  const segments: ScriptSegment[] = [];

  for (const line of lines) {
    const timeMatch = line.match(/<?(\d{1,2})(?::(\d{2}))?\s*-\s*(\d{1,2})(?::(\d{2}))?\s*sec\)?/i);
    const visualMatch = line.match(/\[VISUAL:\s*([^\]]+)\]/i);

    const startSec = timeMatch ? toSeconds(timeMatch[1], timeMatch[2]) : null;
    const endSec = timeMatch ? toSeconds(timeMatch[3], timeMatch[4]) : null;
    const visual = visualMatch ? visualMatch[1].trim() : null;

    segments.push({ startSec, endSec, visual });
  }

  return segments;
}

function toSeconds(s: string, ss?: string): number {
  const a = Number(s || '0');
  const b = ss ? Number(ss) : null;
  if (b !== null) {
    return a * 60 + b;
  }
  return a;
}

function computeDurations(segments: ScriptSegment[], totalDurationSeconds?: number): number[] {
  const durations = segments.map(seg => {
    if (seg.startSec !== null && seg.endSec !== null && seg.endSec > seg.startSec) {
      return seg.endSec - seg.startSec;
    }
    return 0;
  });

  const missingIdx = durations.map((d, i) => (d > 0 ? -1 : i)).filter(i => i >= 0);
  if (missingIdx.length === 0) return durations;

  const totalKnown = durations.reduce((a, b) => a + b, 0);
  const remaining = Math.max(1, (totalDurationSeconds || totalKnown || segments.length * 3) - totalKnown);
  const per = remaining / missingIdx.length;

  for (const i of missingIdx) durations[i] = per;
  return durations;
}
