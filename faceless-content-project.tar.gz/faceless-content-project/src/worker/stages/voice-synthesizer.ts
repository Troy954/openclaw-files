import fs from 'node:fs';
import path from 'node:path';
import type { Channel } from '../../types/index.js';
import { synthesizeSpeech } from '../../lib/elevenlabs.js';
import { getAudioDuration } from '../utils/ffmpeg.js';
import { config } from '../../lib/config.js';

export interface VoiceResult {
  voiceoverPath: string;
  durationSeconds: number;
}

export async function synthesizeVoiceover(script: string, channel: Channel, jobId: string): Promise<VoiceResult> {
  const spokenText = extractSpokenText(script);
  if (!spokenText) throw new Error('Script contains no spoken text after cleanup');

  const audioBuffer = await synthesizeSpeech(spokenText, channel.voice_id || '', channel.voice_settings || {});

  const jobDir = path.join(config.tempDir, jobId);
  fs.mkdirSync(jobDir, { recursive: true });
  const voiceoverPath = path.join(jobDir, 'voiceover.mp3');
  fs.writeFileSync(voiceoverPath, audioBuffer);

  const durationSeconds = await getAudioDuration(voiceoverPath);

  return { voiceoverPath, durationSeconds };
}

export function extractSpokenText(text: string): string {
  const lines = text.split(/\r?\n/);
  const spoken: string[] = [];

  for (const line of lines) {
    const match = line.match(/\bVOICEOVER\b\s*:\s*(.+)$/i) || line.match(/\bV\s*\.?\s*O\.?\b\s*:\s*(.+)$/i);
    if (match && match[1]) {
      spoken.push(match[1].trim());
    }
  }

  return spoken.join('\n').trim();
}
