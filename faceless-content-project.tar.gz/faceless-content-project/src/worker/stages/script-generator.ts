import { openai } from '../../lib/openai.js';
import { config } from '../../lib/config.js';
import type { Channel } from '../../types/index.js';

export async function generateScript(topic: string, duration: number, channel: Channel): Promise<string> {
  const prompt = buildPrompt(topic, duration, channel);

  const response = await openai.chat.completions.create({
    model: config.openaiModel,
    messages: [
      { role: 'system', content: 'You are a viral short-form video scriptwriter.' },
      { role: 'user', content: prompt },
    ],
    temperature: 0.7,
  });

  const text = response.choices?.[0]?.message?.content?.trim();
  if (!text) throw new Error('Empty script response from OpenAI');
  return text;
}

function buildPrompt(topic: string, duration: number, channel: Channel): string {
  return `You are a viral short-form video scriptwriter for ${channel.niche || 'general'} content.

Write a ${duration}-second script for: "${topic}"

Requirements:
- Hook in first 3 seconds that stops the scroll
- Clear value proposition by second 5
- Punchy, conversational tone
- End with engagement CTA (comment, follow, share)
- Each line must follow this exact format:
  "<start>-<end> sec) [VISUAL: ...] VOICEOVER: ..."
- Include a [VISUAL: ...] marker on every line
- Keep timing ranges short (2-5 seconds each) and cover full duration

${channel.content_guidelines || ''}

Output the script only, no explanations.`;
}
