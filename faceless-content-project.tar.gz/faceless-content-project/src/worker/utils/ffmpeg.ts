import ffmpeg from 'fluent-ffmpeg';

export function getAudioDuration(filePath: string): Promise<number> {
  return new Promise((resolve, reject) => {
    ffmpeg.ffprobe(filePath, (err, metadata) => {
      if (err) return reject(err);
      const duration = metadata?.format?.duration;
      if (!duration || Number.isNaN(duration)) return reject(new Error('Unable to determine audio duration'));
      resolve(duration);
    });
  });
}

export function trimVideo(inputPath: string, outputPath: string, startTime: number, duration: number): Promise<void> {
  return new Promise((resolve, reject) => {
    ffmpeg(inputPath)
      .setStartTime(startTime)
      .setDuration(duration)
      .videoFilters([
        'scale=1080:1920:force_original_aspect_ratio=increase',
        'crop=1080:1920',
        'fps=30',
        'format=yuv420p',
      ])
      .noAudio()
      .outputOptions([
        '-c:v libx264',
        '-preset veryfast',
        '-crf 20',
        '-pix_fmt yuv420p',
        '-r 30',
        '-fps_mode cfr',
        '-movflags +faststart',
      ])
      .save(outputPath)
      .on('end', () => resolve())
      .on('error', reject);
  });
}
