import fs from 'node:fs';
import path from 'node:path';

export function slugify(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '')
    .slice(0, 80) || `video-${Date.now()}`;
}

export function createOutputDirectory(baseDir: string, channelId: string, topic: string, date = new Date()): string {
  const yyyy = date.getUTCFullYear();
  const mm = String(date.getUTCMonth() + 1).padStart(2, '0');
  const dd = String(date.getUTCDate()).padStart(2, '0');
  const slug = slugify(topic);
  const dir = path.join(baseDir, channelId, `${yyyy}-${mm}-${dd}`, slug);
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

export function moveToOutput(srcPath: string, destDir: string, filename: string): string {
  const destPath = path.join(destDir, filename);
  fs.renameSync(srcPath, destPath);
  return destPath;
}
