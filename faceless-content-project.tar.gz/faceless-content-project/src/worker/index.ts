import 'dotenv/config';
import { startPoller } from './poller.js';

startPoller().catch(err => {
  console.error('Worker failed to start:', err);
  process.exit(1);
});
