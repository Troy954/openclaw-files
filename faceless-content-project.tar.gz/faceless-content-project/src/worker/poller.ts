import { getNextQueuedJob } from '../db/queries/jobs.js';
import { processJob } from './pipeline.js';
import { config } from '../lib/config.js';

let isRunning = false;

export async function startPoller(): Promise<void> {
  console.log(`Worker poller started (interval=${config.workerPollIntervalMs}ms)`);
  async function loop() {
    if (!isRunning) {
      isRunning = true;
      try {
        const job = await getNextQueuedJob();
        if (job) {
          console.log(`Processing job ${job.id} (${job.topic})`);
          await processJob(job);
        }
      } catch (err) {
        console.error('Poller error:', err);
      } finally {
        isRunning = false;
      }
    }
    setTimeout(loop, config.workerPollIntervalMs);
  }
  loop();
}
