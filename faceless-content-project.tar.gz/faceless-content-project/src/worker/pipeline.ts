import { updateJobStatus } from '../db/queries/jobs.js';
import { createLog } from '../db/queries/logs.js';
import type { VideoJob } from '../db/queries/jobs.js';
import { getChannel } from '../db/queries/channels.js';
import { generateScript } from './stages/script-generator.js';
import { synthesizeVoiceover } from './stages/voice-synthesizer.js';
import { selectFootage } from './stages/footage-selector.js';
import { generateCaptions } from './stages/caption-generator.js';
import { assembleVideo } from './stages/video-assembler.js';
import { createOutputDirectory, moveToOutput } from './utils/file-manager.js';
import { config } from '../lib/config.js';
import fs from 'node:fs';
import path from 'node:path';

export async function processJob(job: VideoJob): Promise<void> {
  const channel = await getChannel(job.channel_id);
  if (!channel) {
    await updateJobStatus(job.id, 'failed', { error_message: 'Channel not found' });
    return;
  }
  if (!channel.is_active) {
    await updateJobStatus(job.id, 'failed', { error_message: 'Channel is inactive' });
    return;
  }

  const scriptStage = 'script';
  let currentStage = scriptStage;
  const startedAt = Date.now();
  await updateJobStatus(job.id, 'processing', { current_stage: scriptStage, started_at: new Date().toISOString() as any });
  await createLog({ job_id: job.id, stage: scriptStage, status: 'started' });

  try {
    const script = await generateScript(job.topic, job.duration, channel);

    // Validate structured script format (must include VISUAL + VOICEOVER)
    if (!/\[VISUAL:[^\]]+\]/i.test(script) || !/\bVOICEOVER\b\s*:/i.test(script)) {
      throw new Error('Script missing required VISUAL and VOICEOVER markers');
    }

    // Save full script (with timing/visual markers) to temp/<job-id>/script.txt
    const jobDir = path.join(config.tempDir, job.id);
    fs.mkdirSync(jobDir, { recursive: true });
    const scriptPath = path.join(jobDir, 'script.txt');
    fs.writeFileSync(scriptPath, script, 'utf8');

    await createLog({ job_id: job.id, stage: scriptStage, status: 'completed', duration_ms: Date.now() - startedAt, details: { script_path: scriptPath } });

    const voiceStage = 'voice';
    currentStage = voiceStage;
    const voiceStartedAt = Date.now();
    await updateJobStatus(job.id, 'processing', { current_stage: voiceStage, script });
    await createLog({ job_id: job.id, stage: voiceStage, status: 'started' });

    const { voiceoverPath, durationSeconds } = await synthesizeVoiceover(script, channel, job.id);

    await createLog({
      job_id: job.id,
      stage: voiceStage,
      status: 'completed',
      duration_ms: Date.now() - voiceStartedAt,
      details: { voiceover_path: voiceoverPath, duration_seconds: durationSeconds },
    });

    // keep durationSeconds for later stages

    const footageStage = 'footage';
    currentStage = footageStage;
    const footageStartedAt = Date.now();
    await updateJobStatus(job.id, 'processing', { current_stage: footageStage, script, voiceover_path: voiceoverPath });
    await createLog({ job_id: job.id, stage: footageStage, status: 'started' });

    const { clipPaths, footageUrls } = await selectFootage(script, job.id, durationSeconds);

    await createLog({
      job_id: job.id,
      stage: footageStage,
      status: 'completed',
      duration_ms: Date.now() - footageStartedAt,
      details: { clip_paths: clipPaths, footage_urls: footageUrls },
    });

    const captionStage = 'captions';
    currentStage = captionStage;
    const captionStartedAt = Date.now();
    await updateJobStatus(job.id, 'processing', {
      current_stage: captionStage,
      script,
      voiceover_path: voiceoverPath,
      footage_urls: JSON.stringify(footageUrls) as any,
    });
    await createLog({ job_id: job.id, stage: captionStage, status: 'started' });

    const captionsPath = await generateCaptions(voiceoverPath, channel, job.id);

    await createLog({
      job_id: job.id,
      stage: captionStage,
      status: 'completed',
      duration_ms: Date.now() - captionStartedAt,
      details: { captions_path: captionsPath },
    });

    const assemblyStage = 'assembly';
    currentStage = assemblyStage;
    const assemblyStartedAt = Date.now();
    await updateJobStatus(job.id, 'processing', {
      current_stage: assemblyStage,
      script,
      voiceover_path: voiceoverPath,
      footage_urls: JSON.stringify(footageUrls) as any,
      captions_path: captionsPath,
    });
    await createLog({ job_id: job.id, stage: assemblyStage, status: 'started' });

    const { videoPath, thumbnailPath } = await assembleVideo({
      clipPaths,
      voiceoverPath,
      captionsPath,
      jobId: job.id,
    });

    const outputDir = createOutputDirectory(channel.output_directory, channel.id, job.topic);
    const finalVideo = moveToOutput(videoPath, outputDir, 'video.mp4');
    const finalThumb = moveToOutput(thumbnailPath, outputDir, 'thumbnail.jpg');

    await updateJobStatus(job.id, 'completed', {
      current_stage: assemblyStage,
      script,
      voiceover_path: voiceoverPath,
      footage_urls: JSON.stringify(footageUrls) as any,
      captions_path: captionsPath,
      output_path: outputDir,
      completed_at: new Date().toISOString() as any,
    });
    await createLog({
      job_id: job.id,
      stage: assemblyStage,
      status: 'completed',
      duration_ms: Date.now() - assemblyStartedAt,
      details: { video_path: finalVideo, thumbnail_path: finalThumb, output_dir: outputDir },
    });
  } catch (err: any) {
    await updateJobStatus(job.id, 'failed', {
      current_stage: currentStage,
      error_message: err?.message || String(err),
    });
    await createLog({ job_id: job.id, stage: currentStage, status: 'failed', duration_ms: Date.now() - startedAt, error: err?.message || String(err) });
  }
}
