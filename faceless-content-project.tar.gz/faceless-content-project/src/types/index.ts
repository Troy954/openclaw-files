export interface VoiceSettings {
  stability?: number;
  similarity_boost?: number;
  style?: number;
  use_speaker_boost?: boolean;
}

export interface CaptionStyle {
  font?: string;
  fontSize?: number;
  primaryColor?: string;
  outlineColor?: string;
  shadowColor?: string;
  position?: 'bottom' | 'middle' | 'top';
}

export interface Channel {
  id: string;
  name: string;
  niche: string | null;
  voice_id: string | null;
  voice_settings: VoiceSettings;
  caption_style: CaptionStyle;
  content_guidelines: string | null;
  output_directory: string;
  is_active: boolean;
  created_at?: string;
  updated_at?: string;
}
